郑州大学 · 多旋翼无人机集群协同搜索仿真 —— 比赛模型提交
=========================================================

一、目录内容
  typhoon_h480_zzufly/
    ├── model.config                  模型清单（指向 typhoon_h480_zzufly.sdf）
    ├── typhoon_h480_0.sdf ~ _5.sdf    ★ 六架逐架 SDF（每架端口/命名空间独立，请按编号使用）
    ├── typhoon_h480_zzufly.sdf        通用 SDF（不含逐架端口，仅作备用/单机）
    └── meshes/                        10 个 STL（外观/碰撞资源，自包含引用）

二、加载方式
  1) 把整个 typhoon_h480_zzufly/ 放进 GAZEBO_MODEL_PATH 下的任一模型库目录；
  2) 逐架加载对应编号文件：<...>/typhoon_h480_zzufly/typhoon_h480_<ID>.sdf
     （eg. gazebo_ros spawn_model -sdf -model typhoon_h480_<ID> -file .../typhoon_h480_<ID>.sdf）
  3) 实例名请保持 typhoon_h480_<ID>（0..5）—— 本模型的多处 robotNamespace 为空，
     会采用运行时模型名，因此实例名决定 ROS 话题前缀。

三、端口（写死在逐架 SDF 内）
  ID:        0      1      2      3      4      5
  mavlink_tcp_port  4560   4561   4562   4563   4564   4565
  mavlink_udp_port  18570  18571  18572  18573  18574  18575
  ※ 通用 SDF（typhoon_h480_zzufly.sdf）只声明 4560/18570，多机请勿使用它。

四、本模型定义的传感器与 ROS 话题（前缀 = 实例名）
  /<实例名>/scan                                    2D 激光：360°，量程 0.08–20 m，50 Hz
  /<实例名>/realsense/depth_camera/color/image_raw   前视彩色 640x480
  /<实例名>/realsense/depth_camera/depth/image_raw   前视深度 640x480 32FC1
  /<实例名>/realsense/stereo_right/depth/image_raw   右侧深度 640x480 32FC1
  /<实例名>/gimbal/camera_imu                        云台 IMU

五、外部依赖（本包不含，需运行环境提供）
  · Gazebo 模型：model://gps、model://sonar
  · PX4 Gazebo 插件（.so，随 PX4 编译产物提供）：
      libgazebo_motor_model.so / libgazebo_multirotor_base_plugin.so /
      libgazebo_ros_laser.so / libgazebo_ros_openni_kinect.so / libgazebo_ros_imu_sensor.so 等
  · meshes 已随包提供，且 SDF 内引用为 model://typhoon_h480_zzufly/meshes/（指向本包自身）
    ⇒ 不依赖其它 typhoon_h480 基础模型目录

六、说明
  · 3d_lidar 相关段落已注释，未启用。
  · 传感器参数（量程/频率/位姿）均在逐架 SDF 内显式声明。
  · 话题清单以上述为准，最终请以启动后的 rostopic 实测为准。

七、裁判方启动本模型及其依赖的命令
--------------------------------------------------
本包另附 zzu_fly_zzufly_model.launch（复用官方 single_vehicle_spawn_xtd.launch
+ mavros px4.launch，仅把 sdf 换成逐架提交件），两种用法任选：

【用法 A · 直接用附带的 launch（推荐）】
  # 1) 让 model://typhoon_h480_zzufly_<i> 可解析：把本包解压目录加入模型库，
  #    并把逐架 SDF 组织成逐架目录（与官方 single_vehicle_spawn 的路径约定一致）：
  #      models/typhoon_h480_zzufly_0/typhoon_h480_zzufly_0.sdf
  #      ...（meshes 可软链，model.config 指向同名 sdf）
  export GAZEBO_MODEL_PATH=<解压目录的父目录>:$GAZEBO_MODEL_PATH
  # 2) 启动（六机；PX4 SITL + 模型 + MAVROS，端口 4560+i / 18570+i / 2454i@3458i）
  roslaunch zzu_fly_zzufly_model.launch num_drones:=6
  #    单机调试： num_drones:=1

【用法 B · 手动逐架 spawn（不依赖任何我们的 launch）】
  # 逐架 SDF 内已写死端口，无需官方那步 xmlstarlet 端口注入：
  for i in 0 1 2 3 4 5; do
    rosrun gazebo_ros spawn_model -sdf \
      -file <解压目录>/typhoon_h480_zzufly/typhoon_h480_$i.sdf \
      -model typhoon_h480_$i -x <X> -y <Y> -z 0 -R 0 -P 0 -Y 0
    # PX4 SITL：P<ID> 对应 -i $i；MAVROS：fcu_url=udp://:2454$i@localhost:3458$i
  done

【注意】官方 robocup.launch 无法加载本模型：
  robocup.launch 内 <arg name="sdf" value="typhoon_h480"/> 是固定值，命令行不可覆盖，
  且其单机 block 只用 xmlstarlet 注入 mavlink_tcp_port（UDP 端口来自 SDF），
  因此本队提交机型需按逐架方式（用法 A/B）加载。Gazebo 世界（robocup.world）、
  人物（control_actor）与计分（score_cal）仍按裁判方原流程启动，本包不涉及。
